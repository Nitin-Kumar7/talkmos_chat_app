 
 

	$(document).ready(function(){
 let base_url= 'https://talkmos.com/'
let validEmail =false;
let validPass =false;
var signUpSubmit =false
 
 
let checkbox = document.getElementById('chkbox1');

let mail_regex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[com]+)*$/;
let main_message = "";

'use strict';

function error_message(e,msg){
 
 
	   let  errorField= $(e).parent().parent().next()
	     let  text= $(errorField.text(msg)) 
	 
	    
	   if(msg==''){
		   $(errorField).removeClass('fa fa-exclamation-circle')
		   	   $(errorField).removeClass('fa fa-check')
		}else{
			$(errorField).addClass('fa fa-exclamation-circle').html(msg).css({'color':'red','font-weight':'400'})
		}
	 
}
 
function success_message(e,msg){
 
	let  errorField= $(e).parent().parent().next()
	console.log(e)
	$(errorField).addClass('fa fa-check').html(msg).css({'color':'green','font-weight':'400'})
	$(errorField).removeClass('fa-exclamation-circle')

}
 
function validinputArr(Arr){
	console.log(Arr)
	if(Arr){
		$.each(Arr,(i,v)=>{
       if(v.val()==''){
		error_message(v,' This Field Is Required')
	   }else{
		error_message(v,'')
	   }
		})
	}

}
function ValidateEmail(input) 
{  
	let value = input.val()
	let result = value.includes("@gmail.com");
	 if(value.length >0){
		 if(result && mail_regex.test(value)){
			 success_message(input,' Valid Email')
			 validEmail =true;
			 return true
			}else{
				error_message(input,' Invalid Email')
				validEmail =false;
				return false

			}
 
		}else{
			error_message(input,'')
		 
		}
	
	}
  
 $('#email').on('keyup',function(){
	let This =$(this);
	ValidateEmail(This) 

})
 let checkSignUpemail =false
 
  
$('#semail').on('keyup',function(){
	let This =$(this);
	
	ValidateEmail(This) 
	if(ValidateEmail(This)){
	  newRagisterAlreadyExist($(this).val()) 
	  
	 
	}
	
 	if(This.val().length >0){
    checkSignUpemail=true
	}else{
		error_message(This,' This Field Is Required')
	}
	  
})
$('#spass').on('keyup',function(){
	let This =$(this);
	if(This.val().length >0){
		error_message(This,'')
	}else{
		error_message(This,' This Field Is Required')
	}
	 
})

$('#scpass').on('keyup',function(){
 
	let This =$(this);
	let pass2 = This.val()
	let pass1 = $('#spass').val()
   if(pass2.length>0){
	   if(pass1 == pass2){
		   success_message(This,' Password Match')
		   validPass =true
		
	   }else{
		   error_message(This,' Password Not Match')
		   validPass =false
	   }
	}else{
		error_message(This,'')
	}

	 
	   
})
// if(checkSignUpemail && validPass){
//     console.log("ok")
//     $('#btn_signup').prop('disabled', false);   
// }else{
//   $('#btn_signup').prop('disabled', true);     
// }
function newRagisterAlreadyExist(email) {
    $.ajax({
        url: base_url + 'Authenticate/isEmailAlreadyExist',
        type: 'post',
        data: { email: email },
        success: function(res) {
            if (res) {
                if (res == "TRUE") {
                    console.log('Email already exists');
                    $('#emailExist').html('Email already exists')
                    signUpSubmit = false;
                  
                  
                } else if (res == "FALSE") {
                     $('#emailExist').html(' ')
                    console.log('New user');
                    signUpSubmit = true;
                  
                }
            }
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.log('AJAX request failed: ' + textStatus + ', ' + errorThrown);
            signUpSubmit = false;
        }
    });
}


	$('#form_login').on('submit',function(e){
		e.preventDefault();
	 
	 
     if(validEmail && $('#pass1').val().length > 0){
		 
		
		 
			 let formData = new FormData(this);
			 $.ajax({
				 url : base_url+'Authenticate/loginData',
				 type : 'post',
				 data : formData,
				 processData:false,
				 contentType: false,
				 success:function(res){
					  
				   
					 if(res=='TRUE'){
						 $('#form_login').trigger('reset');
						 window.location.href =  base_url+"Message";
					 }
					 if(res =='FALSE'){
						  
						 error_message('#email',' It seem like there is No Account with this Email ID')
					 } 
				   
				 }
			 })
			} else{
			         if($('#email').val()=='' || $('#pass1').val()){
						 error_message('#email',' This Field Is Required')
						 error_message('#pass1',' This Field Is Required')
						}else if($('#pass1').val()){
							error_message('#pass1',' This Field Is Required')
						}else if($('#email').val()==''){
							error_message('#email',' This Field Is Required')
						}

				 
			} 
		  
		 

	})



// sign up form 

 
	$('#form_signup').on('submit', function (e) {
		e.preventDefault();
  
       console.log("SIGNUP:"+signUpSubmit )
		if(signUpSubmit && validPass){
			var formData = new FormData(this);
			var date = new Date();
			var fullDate = `${date.getDate()}-${date.getMonth() + 1}-${date.getFullYear()}`;
			formData.append("created_at", fullDate);
		  
			$.ajax({
				url: base_url + 'profile/getSignindetails',
				type: 'post', 
				data: formData,
				processData: false,
				contentType: false,
				success: function (res) {
				  if(res){
				    
					console.log("signup"+ res);
					if(res=="TRUE"){
					  window.location.href =base_url +'profile/setprofile';
					} 

				  }
					 
				}
			})
	     	 
		}else{
			 validinputArr([$('#spass'),$('#scpass'),$('#semail')])
			 
		}
	})
	 

 
// profile set

 
 
	let isNameValid = isLanguageSelected = isGenderSelected = false;

	$('#profile_form').on('submit', function (e) {
		e.preventDefault();
	 
  	isNameValid=  document.getElementById('user_name').hasAttribute('valid') ? true :false
  		isGenderSelected=  document.getElementById('gender_select').hasAttribute('valid') ? true :false
  			isLanguageSelected=  document.getElementById('language-select').hasAttribute('valid') ? true :false
	 
		  
		   // Check if all fields are valid
  if (isNameValid && isLanguageSelected && isGenderSelected) {
  
			if($('#user_image').val()!=''){
			    alert("ok")
                 url =  base_url +'Authenticate/signupData';
				$.ajax({
					url: url,
					type: 'post',
					data: new FormData(this),
					processData: false,
					contentType: false,
					success: function (res) {
						if(res=="TRUE"){
			 	window.location.href = base_url +'Message';
						}
						 	 
					}
				})
				 		
			} 
		  }else{
			  $('#uerror').html('Please enter valid information for all fields').css({'color':'red','font-weight':'400'});

		  }
			 
	})
 
const randomNameGenerator = num => {
  
	let res = '';
	for(let i = 0; i < num; i++){
		const random = Math.floor(Math.random() * 1000);
		
	  res =random  
	};
	return res;
  };
 
const setUsername = name =>{
  
	 if(name!=''){
	   return name.substring(0, name.indexOf('@'))
	 }else{
	  return 'Guest'
	 }
 }
 
  
 
 function firstLetercpatilize(userName) {
	return userName.charAt(0).toUpperCase() + userName.slice(1);
  }
 let userName =   setUsername($('#nameSuggestionList').data('sugestnames'))
 document.getElementById('hello').innerHTML =(firstLetercpatilize(userName)) 

//  $('#user_name').html(userName + randomNameGenerator(2) + '')
 




function getnameList(name){
	let arr =[];
	if(name!=''){
		for (let i = 0; i <= 2; i++) {
			arr.push(`<li>`+((firstLetercpatilize(name)) + randomNameGenerator(2) + '')+`</li>`)
			}
			 
		} 
		$('#nameSuggestionList').html(arr);

	}
 
    
let input = $('#user_name');
let suggestionList = $('#nameSuggestionList');

input.on('input', function() {
  let value = input.text().trim();
  if (value.length > 1) {
    checkName(value);
  } else {
    suggestionList.empty();
  }
});

function checkName(name) {
  $.ajax({
    url: base_url + 'message/isUserAlreadyExist',
    type: 'post',
    data: {username: name},
    success: function(response) {
        $('#uerror').html('UserName Not Available').css({'color':'red','font-weight':'400'})
      if (response == 'true') {
        let arr = [];
        for (let i = 0; i <= 2; i++) {
          arr.push(`<li>` + ((firstLetercpatilize(name)) + randomNameGenerator(2) + '') + `</li>`)
        }
        suggestionList.html(arr);
        suggestionList.find('li').on('click', function() {
          input.html($(this).html());
          $('#display_name').val($(this).html());
          $('#uerror').html('');
        });
      } else {
            $('#uerror').html('')
        suggestionList.empty();
      }
    }
  });
}

 
 

// facebook login
 

    window.fbAsyncInit = function() {
		FB.init({
		  appId      : '2560118200793234',
		  cookie     : true,
		  xfbml      : true,
		  version    : 'v15.0'
		});
		FB.AppEvents.logPageView();   
	  };

	  (function(d, s, id){
		 var js, fjs = d.getElementsByTagName(s)[0];
		 if (d.getElementById(id)) {return;}
		 js = d.createElement(s); js.id = id;
		 js.src = "https://connect.facebook.net/en_US/sdk.js";
		 fjs.parentNode.insertBefore(js, fjs);
	   }(document, 'script', 'facebook-jssdk'));
	   
	   function fbLogin(){
			FB.login(function(response){
				if(response.authResponse){
					fbAfterLogin();
				}
			});
	   }
	   
	   function fbAfterLogin(){
		FB.getLoginStatus(function(response) {
		 
			var d = new Date(),
			messageHour = d.getHours(),
			messageMinute = d.getMinutes(),
			messageSec = d.getSeconds(),
			messageYear = d.getFullYear(),
			messageDate = d.getDate(),
			messageMonth = d.getMonth() + 1,
			signupDate = `${messageYear}-${messageMonth}-${messageDate} ${messageHour}:${messageMinute}:${messageSec}`;


			if (response.status === 'connected') {   
				FB.api('/me', function(response) {
					console.log(response)
				  jQuery.ajax({
					url:base_url +'facebook',
					type:'post',
					data:'name='+response.name+'&id='+response.id+'&created_at='+signupDate,
					success:function(result){
						if(result=='TRUE'){
							window.location.href=base_url + 'Message';
						}
						if(result=='FALSE'){
							window.location.href=base_url + 'profile/setprofile';
						}
						  
					}
				  });
				});
			}
		});
	   }
	   $('#fblogin').on('click',function(){
		   fbLogin()
		})
		$('#fblogin2').on('click',function(){
			fbLogin()
		 })
	 
		 
	
 
})
 
	 
  
 
 
	

	 

  