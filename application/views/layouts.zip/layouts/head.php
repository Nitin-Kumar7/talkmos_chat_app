 
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="<?php echo base_url()?>assets\css\message\bootstrap.min.css">
 
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css" integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/css/message/style.css">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons"rel="stylesheet">
 
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/css/message/messagestyle.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets\css\message\loading-bar.css">
	<!-- emoji library -->
	<link rel="stylesheet" href="https://cdn.rawgit.com/mervick/emojionearea/master/dist/emojionearea.min.css">
 
 
	
	<title >Talkmos</title>
 
 
 
</head>
 
<div class="loaderdpage">
      <div class="preloader">
        <p class="talkmos " >Please Wait...</p>
        <div class="loading-dots">
          <span></span>
          <span></span>
          <span></span>
        </div>
      </div>
    </div> 
