 
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="<?php echo base_url()?>assets\css\message\bootstrap.min.css">
 
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css" integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous">
	<!-- <link rel="stylesheet" type="text/css" href="../assets/css/message/style.css"> -->
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons"rel="stylesheet">
	<!--<script src="https://cdn.jsdelivr.net/npm/pace-js@latest/pace.min.js"></script>-->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/message/loading-bar.css">
	<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>-->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets\css\login\style.css">

 
   
<input type="hidden" class="base_url" value="<?php echo base_url();?>">
	
	<title>Talkmos</title>
 
</head> 
