<?php 
 
 
  
 
 // Check if unique_id exists in session
 if(isset($_SESSION['uniqueid'])) {
     $unique_id = $_SESSION['uniqueid'];
     
   
     // Access other values in session
     $user_name = $_SESSION['user_name'];
    //  $email =  $_SESSION['email'] ?$_SESSION['signupdetails']['email'] :$user_name;
     $user_avtar = $_SESSION['user_avtar'];
  
 } else {
     // Unique ID not found in session
    //  echo "Unique ID not found in session";
 }
 ?>
  

<div id="main_headers" class="bg-dark">
    <input type="hidden" id="get_inque_id" value="<?php echo  $unique_id ? $unique_id : ''?>">
    <input type="hidden" id="user_avtar" value="<?php echo  $user_avtar ? $user_avtar : ''?>">
     <section class="main_headers ">
         <div class="container-xxl ">
             <div class="row">
                 <nav class="navbar navbar-expand-lg navbar-light ">

                     <a class="navbar-brand" href="#"><img src="<?php echo base_url()?>assets/images/logos.png"></a>
                     <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                         data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                         aria-expanded="false" aria-label="Toggle navigation">
                         <span class="navbar-toggler-icon"></span>
                     </button>
                     <div class="collapse navbar-collapse" id="navbarSupportedContent">
                         <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                             <div class="ast-sch">
                                 <div class="input-group">
                                     <button class="btn btn-outline-secondary" type="button" id="button-addon2"><i
                                             class="fa fa-search" aria-hidden="true"></i></button>
                                     <input type="text" name="txt_search" class="form-control" autocomplete="off"
                                         placeholder="Search User" id="search">

                                 </div>
                             </div>
                             <div class="sltc-imgss text-white">
                                 <i class="fa fa-power-off"></i> Logout
                                 <img src="<?php echo base_url()?>upload/<?php echo $user_avtar ? $user_avtar:''?>">
                             </div>



                         </ul>
                         <!-- Example single danger button -->
                         <div class="btn-group">
                             <button type="button" class="setbtn text-white   fa fa-cog  btn  "
                                 data-bs-toggle="dropdown" aria-expanded="false">

                             </button>
                             <ul class="dropdown-menu " style="margin-left: -9rem; z-index:999999;">
                                 <li><a class="dropdown-item" href="#"  data-bs-toggle="modal" data-bs-target="#myprofile"> My Profile</a></li>
                                 <li><a class="dropdown-item" data-bs-toggle="modal" data-bs-target="#exampleModal"
                                         href="#"> Update Profile</a></li>
                                         
                                 <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#passwordChnage"> </i> Change Password</a></li>
                                 <li><a class="dropdown-item" id="logout" href="#"></i> Logout</a></li>

                             </ul>

                         </div>
                     </div>

                 </nav>
             </div>
         </div>
     </section>


    

     <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
         <div class="modal-dialog">
             <div class="modal-content">
                 <div class="modal-header">
                     <h1 class="modal-title fs-5" id="exampleModalLabel">New message</h1>
                     <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                 </div>
                 <div class="modal-body">
                     <form>
                        <input type="hidden" name="useravtar"   id="useravtar">
                        <input type="hidden" name="useravtar"   id="useravtar">
                         <div class=" ">
                             <ul class="nav nav-pills " role="tablist">

                                 <li class="nav-item">
                                     <a class="nav-link" data-bs-toggle="pill" href="#menu1"><img
                                             src="<?php echo base_url()?>upload\avtar1.png" image='avtar1.png'></a>
                                 </li>
                                 <li class="nav-item">
                                     <a class="nav-link" data-bs-toggle="pill" href="#menu2"><img
                                             src="<?php echo base_url()?>upload\avtar2.png" image='avtar2.png'></a>
                                 </li>
                                 <li class="nav-item">
                                     <a class="nav-link" data-bs-toggle="pill" href="#menu3"><img
                                             src="<?php echo base_url()?>upload\avtar3.png" image='avtar3.png'></a>
                                 </li>
                                 <li class="nav-item">
                                     <a class="nav-link" data-bs-toggle="pill" href="#menu4"><img
                                             src="<?php echo base_url()?>upload\avtar4.png" image='avtar4.png'></a>
                                 </li>
                                 <li class="nav-item">
                                     <a class="nav-link" data-bs-toggle="pill" href="#menu5"><img
                                             src="<?php echo base_url()?>upload\avtar5.png" image='avtar5.png'></a>
                                 </li>
                                 <li class="nav-item">
                                     <a class="nav-link" data-bs-toggle="pill" href="#menu6"><img
                                             src="<?php echo base_url()?>upload\avtar6.png" image='avtar6.png'></a>
                                 </li>
                                 <li class="nav-item">
                                     <a class="nav-link" data-bs-toggle="pill" href="#menu7"><img
                                             src="<?php echo base_url()?>upload\avtar7.png" image='avtar7.png'></a>
                                 </li>

                             </ul>
                         </div>
                         <div class=" ">
                             <select id="getselectedGender" class="form-select form-select-sm mb-3" aria-label=".form-select-lg example">
                                 <option selected value="">select Gender</option>
                                 <option value="male">Male</option>
                                 <option value="female">Female</option>

                             </select>
                         </div>
                         <div class=" ">
                             <select id="getselectedlang" class="form-select form-select-sm mb-3" aria-label=".form-select-lg example">
                                 <option  value="" selected>select Language</option>
                                    <option value="en">English</option>
                                    <option value="hi">हिन्दी</option>
                                    <option value="fr">Français</option>
                                    <option value="es">Español</option>
                                    <option value="de">Deutsch</option>
                                    <option value="it">Italiano</option>
                                    <option value="ja">日本語</option>
                                    <option value="ko">한국어</option>
                                    <option value="pt">Português</option>
                                    <option value="ru">Русский</option>
                                    <option value="zh">中文 (简体)</option>
                                    <option value="zh-TW">中文 (繁體)</option>
                                    <option value="ar">العربية</option>
                                    <option value="bn">বাংলা</option>
                                    <option value="sw">Kiswahili</option>

                             </select>
                         </div>
                        

                     </form>
                 </div>
                 <div class="modal-footer">
                     <button type="button" id="closeprofilebox" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                     <button type="button" id="updateProfile" class="btn btn-primary">Send message</button>
                 </div>
             </div>
         </div>
     </div>
     <!-- for Change password_info -->
     <div class="modal fade" id="passwordChnage" tabindex="-1" aria-labelledby="passwordChnage" aria-hidden="true">
         <div class="modal-dialog">
             <div class="modal-content">
                 <div class="modal-header">
                     <h1 class="modal-title fs-5" id="passwordChnage">Update PAssword</h1>
                     <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                 </div>
                 <div class="modal-body">
                     <form>
                       
                         <div class=" ">
                             <label for="recipient-name" id="oldPass" class="col-form-label">Old Password:</label>
                             <input type="text" class="form-control" id="recipient-name">
                         </div>
                         <div class=" ">
                             <label for="recipient-name" id="newPass" class="col-form-label">New Password:</label>
                             <input type="text" class="form-control" id="recipient-name">
                         </div>

                     </form>
                 </div>
                 <div class="modal-footer">
                     <button type="button"  class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                     <button type="button" id="changePassword"  class="btn btn-primary">Submit</button>
                 </div>
             </div>
         </div>
     </div>

     <!-- myprofile -->
          <!-- for Change password_info -->
          <div class="modal fade" id="myprofile" tabindex="-1" aria-labelledby="myprofile" aria-hidden="true">
         <div class="modal-dialog">
             <div class="modal-content">
                 <div class="modal-header">
                     <h1 class="modal-title fs-5" id="myprofile">My Profile </h1>
                     <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                 </div>
                 <div class="modal-body">
                     <form>
                       
                         <div class=" ">
                         <img src="<?php echo base_url()?>upload/<?php echo $user_avtar ? $user_avtar:''?>">
                         </div>
                         <div class="mt-2 ">
                             <h5>User Name :&nbsp; Rahul</h5>
                            </div>
                            <div class="mt-2 ">
                             <h5> Gender :&nbsp; Male</h5>
                             <h5> Language :&nbsp; English</h5>
                            </div>

                     </form>
                 </div>
                 <div class="modal-footer">
                     <button type="button"  class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                 </div>
             </div>
         </div>
     </div>